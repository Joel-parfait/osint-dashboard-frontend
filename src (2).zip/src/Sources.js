import React, { useEffect, useState } from "react";

export default function Sources() {
  const [sources, setSources] = useState([]);
  const [newSource, setNewSource] = useState({ name: "", description: "", url: "" });
  const [loading, setLoading] = useState(false);
  const [viewing, setViewing] = useState(null);

  const fetchSources = async () => {
    setLoading(true);
    try {
      const res = await fetch("http://localhost:8080/sources");
      const data = await res.json();
      setSources(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error("fetchSources:", e);
      setSources([]);
    } finally {
      setLoading(false);
    }
  };

  const addSource = async () => {
    if (!newSource.name.trim()) return alert("Name required");
    try {
      await fetch("http://localhost:8080/sources", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSource),
      });
      setNewSource({ name: "", description: "", url: "" });
      fetchSources();
    } catch (e) {
      console.error("addSource:", e);
      alert("Failed to add source");
    }
  };

  useEffect(() => {
    fetchSources();
  }, []);

  return (
    <div className="sources-page">
      <div className="dashboard-header">
        <h1 className="dashboard-title">Data Sources</h1>
        <p className="dashboard-subtitle">Manage and monitor your intelligence sources</p>
      </div>

      {/* Add Source Card */}
      <div className="source-add-card">
        <h3>Add New Source</h3>
        <div className="source-form">
          <input
            placeholder="Source Name"
            value={newSource.name}
            onChange={(e) => setNewSource({ ...newSource, name: e.target.value })}
            className="source-input"
          />
          <input
            placeholder="Description"
            value={newSource.description}
            onChange={(e) => setNewSource({ ...newSource, description: e.target.value })}
            className="source-input"
          />
          <input
            placeholder="URL (optional)"
            value={newSource.url}
            onChange={(e) => setNewSource({ ...newSource, url: e.target.value })}
            className="source-input"
          />
          <button onClick={addSource} className="source-add-btn">
            + Add Source
          </button>
        </div>
      </div>

      {/* Sources Grid */}
      <div className="sources-grid-enhanced">
        {loading ? (
          <div className="loading-state">Loading sources...</div>
        ) : sources.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📚</div>
            <h3>No Sources Found</h3>
            <p>Add your first data source to get started</p>
          </div>
        ) : (
          sources.map((source, index) => (
            <div key={index} className="source-card-enhanced">
              <div className="source-card-header">
                <div className="source-icon">
                  {source.name?.charAt(0).toUpperCase()}
                </div>
                <div className="source-title">
                  <h3>{source.name}</h3>
                  <span className="source-status active">Active</span>
                </div>
              </div>
              
              <div className="source-description">
                {source.description || "No description provided"}
              </div>

              {source.url && (
                <a href={source.url} target="_blank" rel="noopener noreferrer" className="source-link">
                  🔗 Visit Source
                </a>
              )}

              <div className="source-actions">
                <button className="btn-action btn-view" onClick={() => setViewing(source)}>
                  👁️ View
                </button>
                <button className="btn-action btn-edit">
                  ✏️ Edit
                </button>
                <button className="btn-action btn-delete">
                  🗑️ Delete
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* View Source Modal */}
      {viewing && (
        <div className="modal enhanced-modal">
          <div className="modal-content">
            <div className="modal-header">
              <div className="modal-avatar-large">
                {viewing.name?.charAt(0).toUpperCase()}
              </div>
              <div className="modal-title">
                <h2>{viewing.name}</h2>
                <p>Data Source Details</p>
              </div>
              <button className="modal-close" onClick={() => setViewing(null)}>×</button>
            </div>

            <div className="modal-body">
              <div className="field-group">
                <div className="field-group-header">
                  <span className="group-icon">📝</span>
                  <h4>Description</h4>
                </div>
                <div className="source-detail">
                  {viewing.description || "No description available"}
                </div>
              </div>

              {viewing.url && (
                <div className="field-group">
                  <div className="field-group-header">
                    <span className="group-icon">🔗</span>
                    <h4>URL</h4>
                  </div>
                  <a href={viewing.url} target="_blank" rel="noopener noreferrer" className="source-url">
                    {viewing.url}
                  </a>
                </div>
              )}
            </div>

            <div className="modal-actions">
              <button className="close-btn-enhanced" onClick={() => setViewing(null)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}