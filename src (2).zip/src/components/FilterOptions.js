import React, { useState, useEffect } from "react";
import { getCountryFromRecord, getCountryFromPhoneNumber, getCountryFromAddress } from "../utils/phoneUtils";

export default function FilterOptions({ 
  records, 
  field, 
  value, 
  onChange,
  placeholder = "Select or type..." 
}) {
  const [options, setOptions] = useState([]);
  const [inputValue, setInputValue] = useState(value || "");

  useEffect(() => {
    if (!records || !field) return;

    // Get unique values for the selected field
    let uniqueValues = [];
    
    if (field === "country") {
      // For country, extract from phone numbers and addresses
      const countrySet = new Set();
      records.forEach(r => {
        const country = getCountryFromRecord(r);
        if (country) {
          countrySet.add(country);
        }
      });
      uniqueValues = Array.from(countrySet).sort();
    } else {
      // For other fields, get unique values
      const values = records
        .map(r => r[field])
        .filter(val => val && val.trim() !== "")
        .map(val => String(val).trim());
      
      uniqueValues = [...new Set(values)].sort();
    }
    
    setOptions(uniqueValues);
  }, [records, field]);

  const handleChange = (e) => {
    const newValue = e.target.value;
    setInputValue(newValue);
    onChange(newValue);
  };

  return (
    <div style={{ position: "relative", width: "100%" }}>
      <input
        list={`${field}-options`}
        value={inputValue}
        onChange={handleChange}
        placeholder={placeholder}
        style={{
          width: "100%",
          padding: "0.75rem",
          border: "1px solid rgba(0,0,0,0.1)",
          borderRadius: "10px",
          background: "var(--card)",
          color: "var(--text)",
          fontSize: "0.9rem",
        }}
      />
      <datalist id={`${field}-options`}>
        {options.map((option, index) => (
          <option key={index} value={option} />
        ))}
      </datalist>
    </div>
  );
}