import React, { useRef } from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  BarElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(BarElement, CategoryScale, LinearScale, Tooltip, Legend);

export default function AddressChart({ records = [], onSelectAddress = () => {} }) {
  const chartRef = useRef();

  // Count addresses from address1 field with fallback to placeofbirth
  const counts = records.reduce((acc, r) => {
    const address = (r.address1 || r.placeofbirth || "").trim();
    if (address && address !== "—" && address !== "") {
      acc[address] = (acc[address] || 0) + 1;
    }
    return acc;
  }, {});

  // Get top 10 addresses
  const topAddresses = Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10);

  const labels = topAddresses.map(([address]) => {
    // Truncate long addresses for better display
    return address.length > 20 ? address.substring(0, 20) + '...' : address;
  });
  
  const fullLabels = topAddresses.map(([address]) => address); // Keep full labels for tooltips

  const data = {
    labels,
    datasets: [
      {
        label: "Top Addresses",
        data: topAddresses.map(([_, count]) => count),
        backgroundColor: [
          '#2e5bff', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
          '#06b6d4', '#ec4899', '#84cc16', '#f97316', '#6366f1'
        ],
        borderRadius: 6,
        borderWidth: 0,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: { 
        enabled: true,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        titleColor: '#fff',
        bodyColor: '#fff',
        padding: 12,
        cornerRadius: 6,
        callbacks: {
          title: (context) => {
            return `${fullLabels[context[0].dataIndex]}`;
          },
          label: (context) => {
            return `📊 Records: ${context.parsed.y}`;
          },
          afterLabel: (context) => {
            const totalRecords = records.length;
            const percentage = ((context.parsed.y / totalRecords) * 100).toFixed(1);
            return `📈 ${percentage}% of total`;
          }
        }
      },
    },
    onClick: (evt) => {
      const chart = chartRef.current;
      if (!chart) return;
      const elements = chart.getElementsAtEventForMode(evt.native, "nearest", { intersect: true }, false);
      if (!elements || !elements.length) return;
      const idx = elements[0].index;
      const address = fullLabels[idx];
      if (address) onSelectAddress(address);
    },
    scales: {
      x: {
        ticks: { 
          color: "var(--text)",
          font: {
            size: 11
          },
          maxRotation: 45,
          minRotation: 45,
          padding: 5
        },
        grid: { 
          display: false,
          color: "rgba(255,255,255,0.05)" 
        },
        border: {
          display: false
        }
      },
      y: {
        ticks: { 
          color: "var(--text)",
          font: {
            size: 11
          },
          padding: 5,
          callback: function(value) {
            if (value % 1 === 0) {
              return value;
            }
          }
        },
        grid: { 
          color: "rgba(255,255,255,0.08)",
          borderDash: [4, 4]
        },
        border: {
          display: false
        },
        beginAtZero: true,
      },
    },
  };

  return (
    <div className="chart-card">
      <div className="chart-header" style={{ alignItems: "center", justifyContent: "space-between" }}>
        <h3 style={{ margin: 0 }}>Top 10 Addresses</h3>
        <div style={{ fontSize: 12, color: "var(--muted)" }}>
          {topAddresses.length} addresses • Click to filter
        </div>
      </div>
      <div style={{ height: '250px', marginTop: '10px' }}>
        <Bar ref={chartRef} data={data} options={options} />
      </div>
      {topAddresses.length > 0 && (
        <div style={{ 
          marginTop: '15px', 
          fontSize: '11px', 
          color: 'var(--muted)',
          textAlign: 'center',
          padding: '8px',
          background: 'rgba(0,0,0,0.03)',
          borderRadius: '6px',
          border: '1px solid rgba(0,0,0,0.05)'
        }}>
          Showing top {topAddresses.length} addresses from {records.length} records
        </div>
      )}
    </div>
  );
}