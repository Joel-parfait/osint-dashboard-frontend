import React, { useEffect, useState } from "react";

const REPORTS_KEY = "osint_search_history_v1";
const AUTO_REFRESH_KEY = "osint_auto_refresh_v1";
const CHART_LIMIT_KEY = "osint_chart_limit_v1";
const EXPORT_FORMAT_KEY = "osint_export_format_v1";

/**
 * Settings component (dashboard-relevant tools)
 * - Validate backend: pings /health and GET /sources to show status/count
 * - Export Reports: downloads the local stored reports (works even if server empty)
 * - Auto-refresh toggle (persisted)
 * - Default chart limit (persisted) controls how many top birthplaces to show
 * - Default export format: json or csv (affects Export button behavior)
 */
export default function Settings({ darkMode, setDarkMode }) {
  const [autoRefresh, setAutoRefresh] = useState(false);
  const [chartLimit, setChartLimit] = useState(10);
  const [exportFormat, setExportFormat] = useState("json");
  const [backendStatus, setBackendStatus] = useState({ ok: null, msg: "", sourcesCount: null, checkedAt: null });

  useEffect(() => {
    try {
      const raw = localStorage.getItem(AUTO_REFRESH_KEY);
      setAutoRefresh(raw === "1");
    } catch {
      setAutoRefresh(false);
    }
    try {
      const rawLimit = localStorage.getItem(CHART_LIMIT_KEY);
      if (rawLimit) setChartLimit(Number(rawLimit));
    } catch {}
    try {
      const rawFmt = localStorage.getItem(EXPORT_FORMAT_KEY);
      if (rawFmt) setExportFormat(rawFmt);
    } catch {}
  }, []);

  const toggleAutoRefresh = () => {
    const next = !autoRefresh;
    setAutoRefresh(next);
    try {
      localStorage.setItem(AUTO_REFRESH_KEY, next ? "1" : "0");
    } catch (e) {
      console.error("persist autoRefresh", e);
    }
  };

  const handleChartLimit = (v) => {
    const n = Math.max(1, Math.min(50, Number(v || 10)));
    setChartLimit(n);
    try {
      localStorage.setItem(CHART_LIMIT_KEY, String(n));
    } catch (e) {
      console.error("persist chartLimit", e);
    }
  };

  const handleExportFormat = (fmt) => {
    setExportFormat(fmt);
    try {
      localStorage.setItem(EXPORT_FORMAT_KEY, fmt);
    } catch (e) {
      console.error("persist exportFormat", e);
    }
  };

  const exportReports = () => {
    try {
      const raw = localStorage.getItem(REPORTS_KEY);
      const arr = raw ? JSON.parse(raw) : [];
      if (!arr || arr.length === 0) {
        alert("No reports found locally to export.");
        return;
      }
      if (exportFormat === "json") {
        const blob = new Blob([JSON.stringify(arr, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `reports-${new Date().toISOString()}.json`;
        a.click();
        URL.revokeObjectURL(url);
      } else {
        // CSV
        const headers = ["timestamp", "query", "field", "value", "total", "detail"];
        const rows = arr.map((r) =>
          headers.map((h) => {
            const v = r[h] ?? r[h === "timestamp" ? "timestamp" : h] ?? "";
            // escape quotes
            return `"${String(v).replace(/"/g, '""')}"`;
          }).join(",")
        );
        const csv = [headers.join(","), ...rows].join("\n");
        const blob = new Blob([csv], { type: "text/csv" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `reports-${new Date().toISOString()}.csv`;
        a.click();
        URL.revokeObjectURL(url);
      }
    } catch (e) {
      console.error("exportReports:", e);
      alert("Failed to export reports. See console for details.");
    }
  };

  const validateBackend = async () => {
    const checkedAt = new Date().toLocaleString();
    try {
      // first try /health (common); fallback to /sources count
      let ok = false;
      let msg = "";
      let sourcesCount = null;

      // try /health
      try {
        const res = await fetch("http://localhost:8000/health");
        if (res.ok) {
          ok = true;
          msg = "OK (health)";
        }
      } catch {
        // ignore — try /sources
      }

      if (!ok) {
        try {
          const res2 = await fetch("http://localhost:8000/sources");
          if (res2.ok) {
            const data = await res2.json();
            sourcesCount = Array.isArray(data) ? data.length : null;
            ok = true;
            msg = "OK (sources)";
          } else {
            msg = `Sources endpoint returned ${res2.status}`;
          }
        } catch (e) {
          msg = `Fetch failed: ${e.message || e}`;
        }
      }

      setBackendStatus({ ok, msg, sourcesCount, checkedAt });
      if (!ok) alert(`Backend check failed: ${msg}`);
    } catch (e) {
      console.error("validateBackend:", e);
      setBackendStatus({ ok: false, msg: e.message || String(e), sourcesCount: null, checkedAt });
      alert("Backend validation failed. See console for details.");
    }
  };

  const clearLocalReports = () => {
    if (!window.confirm("Clear local search history? This cannot be undone.")) return;
    try {
      localStorage.removeItem(REPORTS_KEY);
      window.dispatchEvent(new CustomEvent("osint:reports:updated", { detail: [] }));
      alert("Local reports cleared.");
      setBackendStatus((s) => ({ ...s })); // no-op to re-render if needed
    } catch (e) {
      console.error("clearLocalReports:", e);
      alert("Failed to clear local reports.");
    }
  };

  return (
    <div>
      <h2 className="section-title">Settings</h2>

      <div style={{ display: "flex", gap: 12, marginBottom: 12, alignItems: "center" }}>
        <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input type="checkbox" checked={darkMode} onChange={() => setDarkMode(!darkMode)} />
          Enable Dark Mode
        </label>

        <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <input type="checkbox" checked={autoRefresh} onChange={toggleAutoRefresh} />
          Auto-refresh every 60s
        </label>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
        <div style={{ background: "var(--card)", padding: 12, borderRadius: 8 }}>
          <div style={{ fontWeight: 700, marginBottom: 8 }}>Chart options</div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <label style={{ minWidth: 120 }}>Top places to show</label>
            <input
              type="number"
              value={chartLimit}
              onChange={(e) => handleChartLimit(e.target.value)}
              min={1}
              max={50}
              style={{ width: 80, padding: "6px 8px", borderRadius: 6, border: "1px solid rgba(0,0,0,0.08)" }}
            />
          </div>
          <div style={{ marginTop: 8, display: "flex", gap: 8, alignItems: "center" }}>
            <label style={{ minWidth: 120 }}>Default export format</label>
            <select value={exportFormat} onChange={(e) => handleExportFormat(e.target.value)} style={{ padding: "6px 8px", borderRadius: 6 }}>
              <option value="json">JSON</option>
              <option value="csv">CSV</option>
            </select>
          </div>
        </div>

        <div style={{ background: "var(--card)", padding: 12, borderRadius: 8 }}>
          <div style={{ fontWeight: 700, marginBottom: 8 }}>Tools</div>

          <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
            <button onClick={validateBackend} style={{ background: "var(--accent)", color: "#fff", border: "none", padding: "8px 10px", borderRadius: 6, cursor: "pointer" }}>
              Validate Backend
            </button>

            <button onClick={exportReports} style={{ background: "#2563eb", color: "#fff", border: "none", padding: "8px 10px", borderRadius: 6, cursor: "pointer" }}>
              Export Reports
            </button>
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={clearLocalReports} style={{ background: "#ef4444", color: "#fff", border: "none", padding: "8px 10px", borderRadius: 6, cursor: "pointer" }}>
              Clear Local Reports
            </button>
            <button onClick={() => { alert("Resetting UI layout to defaults."); localStorage.removeItem(CHART_LIMIT_KEY); localStorage.removeItem(EXPORT_FORMAT_KEY); setChartLimit(10); setExportFormat("json"); }} style={{ background: "#6b7280", color: "#fff", border: "none", padding: "8px 10px", borderRadius: 6, cursor: "pointer" }}>
              Reset UI Settings
            </button>
          </div>

          <div style={{ marginTop: 12, color: "var(--muted)" }}>
            Backend status: {backendStatus.ok === null ? "Not checked" : (backendStatus.ok ? `OK (${backendStatus.msg})` : `Fail: ${backendStatus.msg}`)}
            {backendStatus.sourcesCount !== null && <div>Sources count: {backendStatus.sourcesCount}</div>}
            {backendStatus.checkedAt && <div style={{ marginTop: 6, fontSize: 12 }}>Last checked: {backendStatus.checkedAt}</div>}
          </div>
        </div>
      </div>

      <div style={{ color: "var(--muted)", fontSize: 13 }}>
        These settings persist locally. Use Export Reports to download the locally-stored search history even when server responses are empty.
      </div>
    </div>
  );
}
