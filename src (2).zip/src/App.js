import React, { useState, useEffect } from "react";
import Dashboard from "./Dashboard";
import Sources from "./Sources";
import Reports from "./Reports";
import Settings from "./Settings";
import Sidebar from "./components/Sidebar";
import "./styles.css";

export default function App() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [darkMode, setDarkMode] = useState(true);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", darkMode ? "dark" : "light");
  }, [darkMode]);

  return (
    <div className="dashboard-layout">
      <Sidebar active={activeTab} onNavigate={setActiveTab} />
      <main className="main-panel">
        {activeTab === "dashboard" && (
          <Dashboard darkMode={darkMode} setDarkMode={setDarkMode} />
        )}
        {activeTab === "sources" && <Sources />}
        {activeTab === "reports" && <Reports />}
        {activeTab === "settings" && <Settings darkMode={darkMode} setDarkMode={setDarkMode} />}
      </main>
    </div>
  );
}
