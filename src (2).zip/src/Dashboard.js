import React, { useState, useRef, useEffect } from "react";
import StatsPanel from "./components/StatsPanel";
import DataTable from "./components/DataTable";
import ProfileModal from "./components/ProfileModal";
import SearchBar from "./components/SearchBar";
import FilterOptions from "./components/FilterOptions";
import AddressChart from "./components/AddressChart";
import CountryChart from "./components/CountryChart";
import "./styles.css";

const API = "http://localhost:8080";

export default function Dashboard({ darkMode, setDarkMode }) {
  const [results, setResults] = useState([]);
  const [allResults, setAllResults] = useState([]);
  const [selected, setSelected] = useState(null);
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [totalCount, setTotalCount] = useState(0);
  const [filterField, setFilterField] = useState("");
  const [filterValue, setFilterValue] = useState("");
  const [filteredView, setFilteredView] = useState(null);
  const [filteredByCountry, setFilteredByCountry] = useState(null);
  const [backendStatus, setBackendStatus] = useState("checking...");
  const [searchSize, setSearchSize] = useState(10000);

  const tableRef = useRef();

  /* =============================
     HEALTH CHECK
     ============================= */
  useEffect(() => {
    fetch(`${API}/search/health`)
      .then(r => r.json())
      .then(() => setBackendStatus("✅ Connected"))
      .catch(() => setBackendStatus("❌ Offline"));
  }, []);

  /* =============================
     SEARCH HANDLER
     ============================= */
  const fetchResults = async (value) => {
    setLoading(true);
    try {
      let url = `${API}/search/name?value=${encodeURIComponent(value)}`;

      if (/^\+?\d+$/.test(value)) {
        url = `${API}/search/phone?value=${value}`;
      } else if (value.includes("@")) {
        url = `${API}/search/email?value=${value}`;
      }

      const res = await fetch(url);
      const data = await res.json();

      setResults(data.results || []);
      setAllResults(data.results || []);
      setTotalCount(data.total || data.results.length);
      setQuery(value || "(all)");

      setTimeout(() => {
        tableRef.current?.scrollIntoView({ behavior: "smooth" });
      }, 100);

    } catch (err) {
      alert("Search failed");
      setResults([]);
      setAllResults([]);
    } finally {
      setLoading(false);
    }
  };

  /* =============================
     FILTER HANDLING
     ============================= */
  const applyFilter = () => {
    if (!filterField || !filterValue) return;

    const filtered = allResults.filter(r =>
      String(r[filterField] || "")
        .toLowerCase()
        .includes(filterValue.toLowerCase())
    );

    setFilteredView(filtered);
  };

  const clearFilter = () => {
    setFilteredView(null);
    setFilteredByCountry(null);
    setResults(allResults);
  };

  /* =============================
     RECORD SELECT
     ============================= */
  const handleSelect = (record) => {
    setSelected(record);
  };

  const shown = filteredView || results;

  /* =============================
     RENDER
     ============================= */
  return (
    <div className={`dashboard-view ${darkMode ? "dark" : ""}`}>
      
      {/* HEADER */}
      <div className="dashboard-header">
        <div className="header-logos">
          <div className="osint-brand">
            <div className="osint-logo">🕵️</div>
            <div>
              <div className="brand-title">OSINT</div>
              <div className="brand-subtitle">Intelligence Platform</div>
            </div>
          </div>

          <button onClick={() => setDarkMode(!darkMode)}>
            {darkMode ? "☀️" : "🌙"}
          </button>
        </div>

        <h1>OSINT Intelligence Dashboard</h1>
        <p>CIRT Onsite OSINT Tool</p>
      </div>

      {/* SEARCH BAR */}
      <SearchBar onSearch={fetchResults} />

      {/* FILTERS */}
      <div className="filters">
        <select value={filterField} onChange={e => setFilterField(e.target.value)}>
          <option value="">No Filter</option>
          <option value="country">Country</option>
          <option value="address1">Address</option>
          <option value="sex">Gender</option>
          <option value="maritalstatus">Marital Status</option>
        </select>

        <input
          placeholder="Filter value..."
          value={filterValue}
          onChange={e => setFilterValue(e.target.value)}
        />

        <button onClick={applyFilter}>Apply</button>
        <button onClick={clearFilter}>Clear</button>
      </div>

      {/* CHARTS */}
      <div className="charts-grid">
        <AddressChart records={allResults} />
        <CountryChart records={allResults} />
      </div>

      {/* STATS */}
      <StatsPanel records={allResults} filteredRecords={shown} />

      {/* TABLE */}
      <div ref={tableRef}>
        <DataTable
          records={shown}
          loading={loading}
          totalCount={totalCount}
          onSelect={handleSelect}
        />
      </div>

      {/* FOOTER */}
      <footer className="audit-footer">
        <strong>
          Showing {shown.length.toLocaleString()} of {totalCount.toLocaleString()}
        </strong>
        <span>Backend: {backendStatus}</span>
      </footer>

      {/* MODAL */}
      {selected && (
        <ProfileModal
          person={selected}
          onClose={() => setSelected(null)}
        />
      )}
    </div>
  );
}
