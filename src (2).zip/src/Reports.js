import React, { useEffect, useState } from "react";

const STORAGE_KEY = "osint_search_history_v1";

export function pushReport(entry) {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    const now = new Date();
    const item = { 
      ...entry, 
      timestamp: now.toLocaleString(),
      id: Date.now() + Math.random()
    };
    const updated = [item, ...arr].slice(0, 500);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    window.dispatchEvent(new CustomEvent("osint:reports:updated", { detail: updated }));
  } catch (e) {
    console.error("pushReport:", e);
  }
}

export default function Reports() {
  const [history, setHistory] = useState([]);
  const [selectedReport, setSelectedReport] = useState(null);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      setHistory(raw ? JSON.parse(raw) : []);
    } catch (e) {
      setHistory([]);
    }

    const handler = (e) => setHistory(e.detail || []);
    window.addEventListener("osint:reports:updated", handler);
    return () => window.removeEventListener("osint:reports:updated", handler);
  }, []);

  const clearAll = () => {
    if (!window.confirm("Clear all reports?")) return;
    localStorage.removeItem(STORAGE_KEY);
    setHistory([]);
    window.dispatchEvent(new CustomEvent("osint:reports:updated", { detail: [] }));
  };

  const filteredReports = history.filter(report => {
    if (filter === "all") return true;
    if (filter === "large") return report.total > 100;
    if (filter === "small") return report.total <= 100;
    return true;
  });

  return (
    <div className="reports-page">
      <div className="dashboard-header">
        <h1 className="dashboard-title">Search Reports</h1>
        <p className="dashboard-subtitle">History of all your searches and results</p>
      </div>

      {/* Reports Header */}
      <div className="reports-header">
        <div className="reports-stats">
          <div className="stat-card-enhanced stat-blue-enhanced">
            <div className="stat-icon-container">📊</div>
            <div className="stat-content-enhanced">
              <h3>Total Reports</h3>
              <div className="stat-value-enhanced">{history.length}</div>
            </div>
          </div>
        </div>

        <div className="reports-controls">
          <select value={filter} onChange={(e) => setFilter(e.target.value)} className="filter-select">
            <option value="all">All Reports</option>
            <option value="large">Large Results (&gt;100)</option>
            <option value="small">Small Results (&lt;=100)</option>
          </select>
          <button onClick={clearAll} className="clear-btn">
            🗑️ Clear All
          </button>
        </div>
      </div>

      {/* Reports Grid */}
      <div className="reports-grid">
        {filteredReports.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📋</div>
            <h3>No Reports Yet</h3>
            <p>Your search reports will appear here</p>
          </div>
        ) : (
          filteredReports.map((report, index) => (
            <div 
              key={report.id || index} 
              className="report-card"
              onClick={() => setSelectedReport(report)}
            >
              <div className="report-header">
                <div className="report-icon">
                  {report.total > 100 ? "📈" : "📄"}
                </div>
                <div className="report-title">
                  <h3>{report.query || "Unknown Search"}</h3>
                  <span className={`report-badge ${report.total > 100 ? 'large' : 'small'}`}>
                    {report.total} results
                  </span>
                </div>
              </div>

              <div className="report-details">
                <div className="report-meta">
                  <span>🔍 {report.field || "All fields"}</span>
                  <span>⏰ {report.timestamp}</span>
                </div>
                
                {report.value && (
                  <div className="report-filter">
                    <strong>Filter:</strong> {report.value}
                  </div>
                )}
              </div>

              <div className="report-actions">
                <button className="btn-action btn-view">
                  👁️ View Details
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Report Detail Modal */}
      {selectedReport && (
        <div className="modal enhanced-modal">
          <div className="modal-content">
            <div className="modal-header">
              <div className="modal-avatar-large">
                {selectedReport.total > 100 ? "📈" : "📄"}
              </div>
              <div className="modal-title">
                <h2>Search Report</h2>
                <p>Detailed information about this search</p>
              </div>
              <button className="modal-close" onClick={() => setSelectedReport(null)}>×</button>
            </div>

            <div className="modal-body">
              <div className="field-group">
                <div className="field-group-header">
                  <span className="group-icon">🔍</span>
                  <h4>Search Query</h4>
                </div>
                <div className="report-detail-card">
                  <div className="detail-item">
                    <label>Query</label>
                    <span>{selectedReport.query || "N/A"}</span>
                  </div>
                  <div className="detail-item">
                    <label>Field</label>
                    <span>{selectedReport.field || "All fields"}</span>
                  </div>
                  <div className="detail-item">
                    <label>Filter Value</label>
                    <span>{selectedReport.value || "No filter"}</span>
                  </div>
                </div>
              </div>

              <div className="field-group">
                <div className="field-group-header">
                  <span className="group-icon">📊</span>
                  <h4>Results</h4>
                </div>
                <div className="results-stats">
                  <div className="stat-mini">
                    <div className="stat-mini-value">{selectedReport.total || 0}</div>
                    <div className="stat-mini-label">Total Results</div>
                  </div>
                  <div className="stat-mini">
                    <div className="stat-mini-value">
                      {selectedReport.total > 100 ? "Large" : "Small"}
                    </div>
                    <div className="stat-mini-label">Size Category</div>
                  </div>
                </div>
              </div>

              <div className="field-group">
                <div className="field-group-header">
                  <span className="group-icon">⏰</span>
                  <h4>Timing</h4>
                </div>
                <div className="timestamp">
                  {selectedReport.timestamp}
                </div>
              </div>
            </div>

            <div className="modal-actions">
              <button className="close-btn-enhanced" onClick={() => setSelectedReport(null)}>
                Close
              </button>
              <button className="export-btn-enhanced" onClick={() => {
                const blob = new Blob([JSON.stringify(selectedReport, null, 2)], { type: "application/json" });
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = `report-${selectedReport.timestamp}.json`;
                a.click();
                URL.revokeObjectURL(url);
              }}>
                📤 Export Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}