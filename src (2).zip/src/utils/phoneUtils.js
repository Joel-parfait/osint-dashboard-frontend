// src/utils/phoneUtils.js

// Country calling codes mapping
export const countryCallingCodes = {
  '237': 'Cameroon',
  '1': 'United States/Canada',
  '33': 'France',
  '44': 'United Kingdom',
  '49': 'Germany',
  '32': 'Belgium',
  '31': 'Netherlands',
  '41': 'Switzerland',
  '233': 'Ghana',
  '27': 'South Africa',
  '234': 'Nigeria',
  '254': 'Kenya',
  '256': 'Uganda',
  '255': 'Tanzania',
  '20': 'Egypt',
  '212': 'Morocco',
  '213': 'Algeria',
  '216': 'Tunisia',
  '229': 'Benin',
  '226': 'Burkina Faso',
  '243': 'DR Congo',
  '242': 'Congo',
  '225': 'Ivory Coast',
  '224': 'Guinea',
  '231': 'Liberia',
  '223': 'Mali',
  '222': 'Mauritania',
  '227': 'Niger',
  '221': 'Senegal',
  '232': 'Sierra Leone',
  '228': 'Togo',
  '7': 'Russia/Kazakhstan',
  '86': 'China',
  '91': 'India',
  '62': 'Indonesia',
  '81': 'Japan',
  '82': 'South Korea',
  '60': 'Malaysia',
  '63': 'Philippines',
  '65': 'Singapore',
  '66': 'Thailand',
  '84': 'Vietnam',
  '61': 'Australia',
  '64': 'New Zealand',
  '55': 'Brazil',
  '54': 'Argentina',
  '56': 'Chile',
  '57': 'Colombia',
  '52': 'Mexico',
  '51': 'Peru',
  '34': 'Spain',
  '39': 'Italy',
  '48': 'Poland',
  '351': 'Portugal',
  '40': 'Romania',
  '46': 'Sweden',
  '90': 'Turkey',
  '380': 'Ukraine',
  '971': 'UAE',
  '966': 'Saudi Arabia',
  '962': 'Jordan',
  '965': 'Kuwait',
  '968': 'Oman',
  '974': 'Qatar',
  '961': 'Lebanon'
};

// Helper function to extract country from phone number
export function getCountryFromPhoneNumber(phoneNumber) {
  if (!phoneNumber) return null;
  
  // Remove all non-digit characters
  const digits = phoneNumber.replace(/\D/g, '');
  
  if (digits.length < 5) return null;
  
  // Check for country codes (1-3 digits)
  // Start with longest codes first (3-digit, then 2-digit, then 1-digit)
  for (let i = 3; i >= 1; i--) {
    const code = digits.substring(0, i);
    if (countryCallingCodes[code]) {
      return countryCallingCodes[code];
    }
  }
  
  return null;
}

// Function to get country code (for flags, etc.)
export function getCountryCodeFromPhoneNumber(phoneNumber) {
  if (!phoneNumber) return null;
  
  const digits = phoneNumber.replace(/\D/g, '');
  
  for (let i = 3; i >= 1; i--) {
    const code = digits.substring(0, i);
    if (countryCallingCodes[code]) {
      return code;
    }
  }
  
  return null;
}

// Function to format phone number
export function formatPhoneNumber(phone) {
  if (!phone) return '';
  
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, '');
  
  if (digits.length <= 9) return phone;
  
  // Format based on length
  if (digits.length === 12) {
    // Format as +XXX XXX XXX XXX
    return `+${digits.slice(0, 3)} ${digits.slice(3, 6)} ${digits.slice(6, 9)} ${digits.slice(9)}`;
  } else if (digits.length === 13) {
    // Format as +XXX XXX XXX XXXX
    return `+${digits.slice(0, 3)} ${digits.slice(3, 6)} ${digits.slice(6, 9)} ${digits.slice(9)}`;
  } else {
    // Generic format
    return `+${digits}`;
  }
}

// Add this function - Helper function to get country flag emoji
export function getCountryFlag(country) {
  const countryFlags = {
    'Cameroon': '🇨🇲',
    'Nigeria': '🇳🇬',
    'France': '🇫🇷',
    'United States/Canada': '🇺🇸',
    'United Kingdom': '🇬🇧',
    'Germany': '🇩🇪',
    'Kenya': '🇰🇪',
    'South Africa': '🇿🇦',
    'China': '🇨🇳',
    'India': '🇮🇳',
    'Russia/Kazakhstan': '🇷🇺',
    'Brazil': '🇧🇷',
    'Ghana': '🇬🇭',
    'Belgium': '🇧🇪',
    'Netherlands': '🇳🇱',
    'Switzerland': '🇨🇭',
    'USA': '🇺🇸',
    'UK': '🇬🇧',
    'Senegal': '🇸🇳',
    'Ivory Coast': '🇨🇮',
    'Egypt': '🇪🇬',
    'Morocco': '🇲🇦',
    'Algeria': '🇩🇿',
    'Tunisia': '🇹🇳',
    'Uganda': '🇺🇬',
    'Tanzania': '🇹🇿',
    'DR Congo': '🇨🇩',
    'Congo': '🇨🇬',
    'Benin': '🇧🇯',
    'Burkina Faso': '🇧🇫',
    'Mali': '🇲🇱',
    'Niger': '🇳🇪',
    'Chad': '🇹🇩',
    'Central African Republic': '🇨🇫',
    'Gabon': '🇬🇦',
    'Equatorial Guinea': '🇬🇶',
    'Sao Tome and Principe': '🇸🇹',
    'Rwanda': '🇷🇼',
    'Burundi': '🇧🇮',
    'Ethiopia': '🇪🇹',
    'Somalia': '🇸🇴',
    'Djibouti': '🇩🇯',
    'Eritrea': '🇪🇷',
    'Sudan': '🇸🇩',
    'South Sudan': '🇸🇸',
    'Angola': '🇦🇴',
    'Mozambique': '🇲🇿',
    'Zambia': '🇿🇲',
    'Zimbabwe': '🇿🇼',
    'Malawi': '🇲🇼',
    'Botswana': '🇧🇼',
    'Namibia': '🇳🇦',
    'Lesotho': '🇱🇸',
    'Eswatini': '🇸🇿',
    'Madagascar': '🇲🇬',
    'Mauritius': '🇲🇺',
    'Seychelles': '🇸🇨',
    'Comoros': '🇰🇲',
    'Mauritania': '🇲🇷',
    'Liberia': '🇱🇷',
    'Sierra Leone': '🇸🇱',
    'Guinea': '🇬🇳',
    'Guinea-Bissau': '🇬🇼',
    'Gambia': '🇬🇲',
    'Cape Verde': '🇨🇻',
    'Spain': '🇪🇸',
    'Italy': '🇮🇹',
    'Portugal': '🇵🇹',
    'Greece': '🇬🇷',
    'Austria': '🇦🇹',
    'Denmark': '🇩🇰',
    'Sweden': '🇸🇪',
    'Norway': '🇳🇴',
    'Finland': '🇫🇮',
    'Ireland': '🇮🇪',
    'Poland': '🇵🇱',
    'Czech Republic': '🇨🇿',
    'Slovakia': '🇸🇰',
    'Hungary': '🇭🇺',
    'Romania': '🇷🇴',
    'Bulgaria': '🇧🇬',
    'Serbia': '🇷🇸',
    'Croatia': '🇭🇷',
    'Slovenia': '🇸🇮',
    'Bosnia': '🇧🇦',
    'Albania': '🇦🇱',
    'Montenegro': '🇲🇪',
    'Kosovo': '🇽🇰',
    'Macedonia': '🇲🇰',
    // Add more as needed
  };
  return countryFlags[country] || '🌍';
}

// Add this function to extract country from address
export function getCountryFromAddress(address) {
  if (!address) return null;
  
  const addressLower = address.toLowerCase();
  
  // Country name variations in addresses
  const countryPatterns = {
    'Cameroon': ['cameroon', 'cam', 'cmr', 'cameroun', 'yaounde', 'douala', 'bamenda', 'bafoussam', 'garoua', 'maroua'],
    'Nigeria': ['nigeria', 'ng', 'naija', 'nigerian', 'lagos', 'abuja', 'kano', 'ibadan', 'port harcourt'],
    'France': ['france', 'fr', 'french', 'paris', 'marseille', 'lyon', 'toulouse'],
    'United States/Canada': ['usa', 'us', 'america', 'canada', 'ca', 'united states', 'new york', 'los angeles', 'chicago', 'toronto', 'vancouver'],
    'United Kingdom': ['uk', 'britain', 'england', 'united kingdom', 'gb', 'great britain', 'london', 'manchester', 'birmingham'],
    'Germany': ['germany', 'deutschland', 'de', 'berlin', 'hamburg', 'munich', 'cologne'],
    'Belgium': ['belgium', 'be', 'belgian', 'brussels', 'antwerp', 'ghent'],
    'Netherlands': ['netherlands', 'nl', 'dutch', 'holland', 'amsterdam', 'rotterdam', 'the hague'],
    'Switzerland': ['switzerland', 'ch', 'swiss', 'zurich', 'geneva', 'bern', 'basel'],
    'Ghana': ['ghana', 'gh', 'accra', 'kumasi', 'tamale'],
    'South Africa': ['south africa', 'sa', 'rsa', 'cape town', 'johannesburg', 'durban', 'pretoria'],
    'Kenya': ['kenya', 'ke', 'nairobi', 'mombasa', 'kisumu'],
    'China': ['china', 'cn', 'beijing', 'shanghai', 'guangzhou'],
    'India': ['india', 'in', 'mumbai', 'delhi', 'bangalore'],
    'Russia/Kazakhstan': ['russia', 'ru', 'russian', 'kazakhstan', 'kz', 'moscow', 'saint petersburg'],
    'Brazil': ['brazil', 'br', 'sao paulo', 'rio de janeiro', 'brasilia'],
  };
  
  for (const [country, patterns] of Object.entries(countryPatterns)) {
    for (const pattern of patterns) {
      if (addressLower.includes(pattern.toLowerCase())) {
        return country;
      }
    }
  }
  
  return null;
}

// New function to get country from record (combines phone and address)
export function getCountryFromRecord(record) {
  if (!record) return null;
  
  // Try phone first
  const phoneCountry = getCountryFromPhoneNumber(record.phonenumber);
  if (phoneCountry) return phoneCountry;
  
  // Try address
  const address = record.address1 || record.placeofbirth || "";
  const addressCountry = getCountryFromAddress(address);
  if (addressCountry) return addressCountry;
  
  return null;
}